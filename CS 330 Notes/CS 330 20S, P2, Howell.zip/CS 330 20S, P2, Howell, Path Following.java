/*
 * Name:        Cameron R. Howell
 * Class:       CS 330 Spring 2020
 * Assignment:  Programming 2
 * Purpose:     This program generates CSV text files that contain parameters for generating a motion plot.
 * Date:        2 March 2020
 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.lang.Math;

public class SimpleMovement {
    public static int scenario = 7;                                 //Either 7 or 8
    public static double[] closestPoint = new double[2];
    public static double currentParam = 0.0;
    public static double time = 0.0;
    public static double deltaTime = 0.5;
    public static List<Character> Characters = new ArrayList<>();
    public static List<Path> Paths = new ArrayList<>();
    public static double[] pairA;
    public static double[] pairB;
    public static double[] steering;
    public static final int FOLLOW_PATH = 8;
    public static boolean physics = false;                          //If true, HS physics. If false, NE1 integration

    public static void main (String[] args) throws IOException {
        if (scenario == 7){
            Character char1 = new Character(71, FOLLOW_PATH, new double[]{-90.0, 60.0}, new double[]{0.0, 0.0}, new double[]{0.0, 0.0}, 0.0, 0.0, 0.0, 1.5, 1.0, 0.0, 0.0, 0.05, 1, false);

            Character char2 = new Character(72, FOLLOW_PATH, new double[]{75.0, -10.0}, new double[]{0.0, 0.0}, new double[]{0.0, 0.0}, 0.0, 0.0, 0.0, 2.0, 1.0, 0.0, 0.0, 0.05, 2, false);

            Characters.add(char1);
            Characters.add(char2);

            Path path1 = pathPrep(83, new double[] {-80, -40, 40, 80}, new double[]{40, 70, 10, 40});

            Path path2 = pathPrep(84, new double[] {70, 25, 45, -55, -35, -80}, new double[] {-25, -20, -80, -80, -20, -25});

            Paths.add(path1);
            Paths.add(path2);

        } else if (scenario == 8){
            Character char1 = new Character(81, FOLLOW_PATH, new double[]{-90.0, 60.0}, new double[]{0.0, 0.0}, new double[]{0.0, 0.0}, 0.0, 0.0, 0.0, 3.0, 1.0, 0.0, 0.0, 0.05, 1, false);

            Character char2 = new Character(82, FOLLOW_PATH, new double[]{75.0, -10.0}, new double[]{0.0, 0.0}, new double[]{0.0, 0.0}, 0.0, 0.0, 0.0, 3.0, 1.0, 0.0, 0.0, 0.05, 2, false);

            Characters.add(char1);
            Characters.add(char2);

            Path path1 = pathPrep(83, new double[] {-80, -40, 40, 80}, new double[]{40, 70, 10, 40});

            Path path2 = pathPrep(84, new double[] {70, 25, 45, -55, -35, -80}, new double[] {-25, -20, -80, -80, -20, -25});

            Paths.add(path1);
            Paths.add(path2);

        }

        File f = new File("CS 330 20S, P2, Howell, Trajectory 7.txt");      //Change filename to generate new file, or leave same to overwrite file
        FileWriter fw = new FileWriter(f);

        for (Character i : Characters){
            fw.write(time + "," + i.id + "," + i.position[0] + "," + i.position[1] + "," + i.velocity[0] + "," + i.velocity[1] + "," + i.linear[0] + "," + i.linear[1] + "," + i.orientation + "," + i.steer + "\n");
        }

        while (time < 100) {         //Calls appropriate function for motion calculations, then appends value to the text file
            time += deltaTime;

            for (Character c : Characters){
                if (c.steer == FOLLOW_PATH){
                    int path = c.path;
                    steering = dynamicGetSteeringPathFollow(c, Paths.get(path - 1));
                }
                c.linear[0] = steering[0];
                c.linear[1] = steering[1];
                c.angular = steering[2];
                dynamicUpdate(c, steering, deltaTime, physics);
                if (c.align){
                    c.orientation = Math.atan2(c.velocity[1], c.velocity[0]);
                }
            }

            for (Character c : Characters){
                fw.write(time + "," + c.id + "," + c.position[0] + "," + c.position[1] + "," + c.velocity[0] + "," + c.velocity[1] + "," + c.linear[0] + "," + c.linear[1] + "," + c.orientation + "," + c.steer + "\n");
            }
        }

        fw.close();
    }

    /*
        Dynamic steering methods. PathFollow gets the position and target position; then, Seek gets the linear and angular. DynamicUpdate runs every timestep to update these values on the appropriate character
     */
    public static double[] dynamicGetSteeringSeek(Character c, double[] t){
        double[] result = {0, 0, 0};
        result[0] = t[0] - c.position[0];
        result[1] = t[1] - c.position[1];
        vectorNormalize(result);
        result[0] = result[0] * c.maxAcceleration;
        result[1] = result[1] * c.maxAcceleration;
        result[2] = 0;
        return result;
    }

    public static double[] dynamicGetSteeringPathFollow(Character c, Path path){
        currentParam = path.getParam(c.position);
        double targetParam = Math.min(1, currentParam + c.offset);
        double[] targetPosition = path.getPosition(targetParam);
        double[] t = {targetPosition[0], targetPosition[1]};
        return(dynamicGetSteeringSeek(c, t));
    }

    public static void dynamicUpdate (Character mover, double[] steering, double dT, boolean p){
        double half_t_sq;
        if (p){
            half_t_sq = 0.5 * dT * dT;
            mover.position[0] += (mover.velocity[0] * dT) + (steering[0] * half_t_sq);
            mover.position[1] += (mover.velocity[1] * dT) + (steering[1] * half_t_sq);
            mover.orientation += (mover.rotation * dT) + (steering[2] * half_t_sq);
        } else {
            mover.position[0] += (mover.velocity[0] * dT);
            mover.position[1] += (mover.velocity[1] * dT);
            mover.orientation += (mover.rotation * dT);
        }
        mover.velocity[0] += (steering[0] * dT);
        mover.velocity[1] += (steering[1] * dT);
        mover.rotation += (steering[2] * dT);
        if (vectorLength(mover.velocity) > mover.maxSpeed){
            vectorNormalize(mover.velocity);
            mover.velocity[0] *= mover.maxSpeed;
            mover.velocity[1] *= mover.maxSpeed;
        }
    }

    /*
        Vector methods for calculating vector length, normalization, dot product
    */
    public static double vectorLength(double[] v){
        return (Math.sqrt(Math.pow(v[0], 2) + Math.pow(v[1], 2)));
    }

    public static void vectorNormalize(double[] v){
        double len = vectorLength(v);
        if (len != 0){
            v[0] /= len;
            v[1] /= len;
        } else {
            v[0] = 0.0;
            v[1] = 0.0;
        }
    }

    public static double vectorDot(double[] A, double[] B){
        double sum = 0.0;
        for (int i = 0; i < A.length; i++){
            sum += (A[i] * B[i]);
        }
        return sum;
    }

    /*
        Geometric methods for calculating distances
    */
    public static double distancePointToPoint (double[] a, double[] b){
        double val = (b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1]);
        return (Math.sqrt(val));
    }

    public static double[] closestPointSegment(double[] Q, double[] A, double[] B){
        double[] temp1 = new double[2];
        double[] temp2 = new double[2];

        for (int k = 0; k < Q.length; k++){
            temp1[k] = Q[k] - A[k];
            temp2[k] = B[k] - A[k];
        }
        double T = vectorDot(temp1, temp2) / vectorDot(temp2, temp2);

        if (T <= 0) {
            return A;
        } else if (T >= 1){
            return B;
        } else {
            temp2[0] *= T;
            temp2[1] *= T;
            A[0] += temp2[0];
            A[1] += temp2[1];
            return A;
        }
    }

    public static Path pathPrep(int pathID, double[] pathX, double[] pathY){
        double max = 0.0;
        int pathSegments = pathX.length - 1;
        double[] pathDistance = new double[pathSegments + 1];
        for (int i = 1; i < pathSegments + 1; i++){
            pairA = new double[]{pathX[i - 1], pathY[i - 1]};
            pairB = new double[]{pathX[i], pathY[i]};
            pathDistance[i] = pathDistance[i - 1] + distancePointToPoint(pairA, pairB);
        }
        double[] pathParam = new double[pathSegments + 1];
        for (double v : pathDistance) {
            if (v > max) {
                max = v;
            }
        }
        for (int i = 1; i < pathSegments + 1; i++){
            pathParam[i] = pathDistance[i] / max;
        }

        return new Path(pathID, pathX, pathY, pathDistance, pathParam, pathSegments);
    }
}

/*
This Character class is used to instantiate character objects with the desired values
 */
class Character {
    int id;
    int steer;
    double[] position;
    double[] velocity;
    double[] linear;
    double orientation;
    double rotation;
    double angular;
    double maxSpeed;
    double maxAcceleration;
    double targetRadius;
    double slowRadius;
    double offset;
    int path;
    boolean align;

    //Character constructor
    Character (int i, int s, double[] p, double[] v, double[] l, double o, double r, double a, double mS, double mA, double tR, double sR, double off, int path, boolean align){
        this.id = i;
        this.steer = s;
        this.position = p;
        this.velocity = v;
        this.linear = l;
        this.orientation = o;
        this.rotation = r;
        this.angular = a;
        this.maxSpeed = mS;
        this.maxAcceleration = mA;
        this.targetRadius = tR;
        this.slowRadius = sR;
        this.offset = off;
        this.path = path;
        this.align = align;
    }
}

/*
    The Path class handles path instantiation and all path methods (excluding pathPrep), i.e. path.getParam, path.getPosition.
 */
class Path extends SimpleMovement{
    int id;
    double[] x;
    double[] y;
    double[] distance;
    double[] param;
    int segments;

    //Path constructor
    Path (int i, double[] x, double[] y, double[] d, double[] p, int s){
        this.id = i;
        this.x = x;
        this.y = y;
        this.distance = d;
        this.param = p;
        this.segments = s;
    }

    public double[] getPosition(double par) {
        int j = 0;
        double max = this.param[0];
        for (int i = 1; i < this.param.length; i++){
            if (this.param[i] < par){
                max = this.param[i];
                j = i;
            }
        }
        double T = (par - this.param[j]) / (this.param[j + 1] - this.param[j]);
        double[] A = new double[]{this.x[j], this.y[j]};
        double[] B = new double[]{this.x[j + 1], this.y[j + 1]};
        double[] S = new double[2];
        for (int k = 0; k < A.length; k++){
            S[k] = A[k] + (T * (B[k] - A[k]));
        }

        return S;
    }

    public double getParam(double[] position){
        double closestDist = Double.POSITIVE_INFINITY;
        int closestSegment = 0;
        double[] A;
        double[] B;
        double[] checkpoint;
        for (int i = 0; i < this.segments; i++){
            A = new double[]{this.x[i], this.y[i]};
            B = new double[]{this.x[i + 1], this.y[i + 1]};
            checkpoint = closestPointSegment(position, A, B);
            double checkDist = distancePointToPoint(position, checkpoint);
            if (checkDist < closestDist){
                closestPoint = checkpoint;
                closestDist = checkDist;
                closestSegment = i;
            }
        }
        A = new double[]{this.x[closestSegment], this.y[closestSegment]};
        double A_param = this.param[closestSegment];
        B = new double[]{this.x[closestSegment + 1], this.y[closestSegment + 1]};
        double B_param = this.param[closestSegment + 1];
        double[] S = closestPoint;
        double[] t_1 = new double[S.length];
        for (int j = 0; j < S.length; j++){
            t_1[j] = S[j] - A[j];
        }
        double[] t_2 = new double[B.length];
        for (int k = 0; k < B.length; k++){
            t_2[k] = B[k] - A[k];
        }
        double T = vectorLength(t_1) / vectorLength(t_2);
        return(A_param + (T * (B_param - A_param)));
    }
}
