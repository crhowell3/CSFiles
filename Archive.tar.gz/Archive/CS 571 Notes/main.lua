xx = display.contentCenterX;
yy = display.contentCenterY;
local ref = display.newRect(xx, yy, 100, 100);
ref:setFillColor(1, 0, 0, 0.5);
local a = display.newRect( 0, 0, 100, 100);
