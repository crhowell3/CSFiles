#include <stdio>

int main(){
  print("Hello World!");
  return 0;
}
